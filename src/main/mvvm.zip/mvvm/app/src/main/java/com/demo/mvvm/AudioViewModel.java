package com.demo.mvvm;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class AudioViewModel extends ViewModel {

    public EditItem getUserLiveData() {
        return userLiveData;
    }

    public void setUserLiveData(EditItem userLiveData) {
        this.userLiveData = userLiveData;
    }

    EditItem  userLiveData;

    public AudioViewModel(EditItem  user) {
        this.userLiveData = user;
    }

    public void click() {
        userLiveData.setItemLocation("A");
    }

    public void click(int status) {
        userLiveData.setStatus(status);
    }


}

package com.demo.mvvm;

import androidx.databinding.BaseObservable;
import androidx.databinding.Bindable;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;

public class User extends BaseObservable   {
    public final static int STATUS_START = 0;
    public final static int STATUS_RECORDING = 1;
    public final static int STATUS_PLAYBACK = 2;
    public final static int STATUS_DOWN = 3;


    @Bindable
    public String itemLocation;

    @Bindable
    public int mStatus = 0;

    public User(String itemLocation) {
        this.itemLocation = itemLocation;
    }

    public String getItemLocation() {
        return itemLocation;
    }

    public void setItemLocation(String itemLocation) {
        this.itemLocation = itemLocation;
        notifyPropertyChanged(BR.itemLocation);
    }

    public void setStatus(int status) {
        this.mStatus = status;
        notifyPropertyChanged(BR.status);
    }
}

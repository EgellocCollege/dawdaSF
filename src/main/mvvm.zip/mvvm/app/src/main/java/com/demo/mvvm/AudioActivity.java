package com.demo.mvvm;

import android.os.Bundle;

import com.demo.mvvm.databinding.ActivityAudioBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.databinding.DataBindingUtil;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class AudioActivity extends AppCompatActivity {


    ActivityAudioBinding binding;
    EditItem mEditItem;
    AudioViewModel model;
    List<User> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_audio);

        mEditItem = new EditItem("X");
        mEditItem.addOnPropertyChangedCallback();
         model =  new AudioViewModel(mEditItem);

        binding.setItemData(mEditItem);
        binding.setViewmodel(model);


        final List<User> users = new ArrayList<>();



        users.add(new User("A"));
        users.add(new User("B"));
        users.add(new User("C"));
        users.add(new User("D"));
        users.add(new User("E"));
        users.add(new User("F"));


         UserAdapter adapter = new UserAdapter(users);
         binding.pager.setAdapter(adapter);

        binding.pager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {

            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                mEditItem.setStatus(users.get(position).mStatus);
            }
        });




    }

}
